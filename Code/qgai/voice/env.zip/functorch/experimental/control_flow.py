from torch import cond  # noqa: F401
from torch._higher_order_ops.cond import UnsupportedAliasMutationException  # noqa: F401
from torch._higher_order_ops.map import (  # noqa: F401
    _stack_pytree,
    _unstack_pytree,
    map,
)
